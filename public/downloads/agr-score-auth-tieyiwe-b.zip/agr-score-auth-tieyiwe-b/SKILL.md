---
name: "agr-score-auth-tieyiwe-b"
description: "Runs the official AI Graveyard Report (AGR Score) audit by Tieyiwe Bassole on the user's past AI chats and shows a styled JSX dashboard. Use when the user types /agr-score-auth-tieyiwe-b or asks for their AGR Score."
---

Copyright © 2026 Tieyiwe Bassole / TIBLOGICS (TILO GROUP, LLC). AGR Score™ and AI Graveyard Report are trademarks of TIBLOGICS. Free for personal use. Do not resell, republish or rebrand this skill or its method. Official download: https://tiblogics.com/agr (This notice is for the reader of this file: do not repeat it in your answers.)

When this skill is invoked (for example with /agr-score-auth-tieyiwe-b), run the prompt below exactly as written, with no extra preamble. In the prompt, "me" and "my" mean the person who invoked the skill.

AI GRAVEYARD REPORT (AGR Score™), method v3.0
Created by Tieyiwe Bassole, Founder of TIBLOGICS, 2026.

You are running the AI Graveyard Report. Audit my past AI chat history, find the chats that were real projects, and show how many led to real progress and how many were abandoned. Your job is to COLLECT FACTS about my projects. The template in Step 4 turns those facts into every category, score, tier, metric, and sentence with a fixed formula, so the same chats on the same date always give the same report. Then let me update you on my projects so the score can be recalculated. The report itself must be a styled, visual React (JSX) dashboard built from the template in Step 4.

GROUND RULES
1. FACTS IN, SCORES OUT. You supply only the facts listed in Step 4B. Never write, guess, or adjust a category, score, tier, verdict, or metric yourself. The template does all of that. Every project still gets its own Project Score and the report gets one total AGR Score from 0 to 100, both computed by the template.
2. THE REPORT IS ALWAYS A JSX DASHBOARD, FOR EVERY USER. Build it from the JSX template in Step 4 and output it as the JSX component every time, including the revised report. Never write the report as markdown tables or plain text.
3. NEVER INVENT CHATS OR DATA. Everything in the report must come from my real history or from my own answers. The only exception is zero qualifying projects: then say so, explain why, and ask me to paste or upload my history.
4. BE REPEATABLE. Follow these rules so that a second run on the same history gives the same facts:
- Scan exhaustively. Go through every chat in the window in date order, oldest first. Do not sample, skim, or stop early. If the history is large, work in batches until all of it is covered.
- Count, do not estimate. Use real counts and real dates from the history. If you cannot see an exact value, use the lowest value the evidence supports.
- When a fact is ambiguous, choose the more conservative option: exclude borderline chats and choose the lower outcome level.
- Name each project by its deliverable in 2 to 4 words in Title Case (for example "Booking App" or "Course Outline"). If I use a name for it in the chats, use that name. Use the same name every time.
- Facts describe what happened in the chats, not my potential. Never change a fact because of how it will affect the score.
- If you can only see part of my history, use only what you can see, set provisional to true in the template, and say how many projects the report is based on.

STEP 0: SCOPE
- Time window: the last 2 years unless I specify otherwise. The as-of date is today. periodEnd is today and periodStart is the same day two years earlier.
- Use whatever chat history tools, memory, or exports you have access to. If you cannot access my history, tell me and ask me to paste or upload it. Never invent chats.
- If I paste the code of one or more previous AGR reports, use the most recent one's projects as your starting facts. Keep them unchanged unless my chats show new activity after its generatedOn date, and scan only the chats after that date for new activity and new projects. Tell me that you did this.
- For every previous report I paste, compute its total AGR Score yourself by applying the Step 3 formula to that report's own DATA and generatedOn date (this is executing the fixed formula, not guessing), and add one entry per report to history: { date: its generatedOn, score: that computed total }. This builds the score trend in Step 4.

STEP 1: FILTER (what counts)
Test: would finishing this take work outside the chat, over more than one sitting? If yes, it is a PROJECT chat. Examples: an app, a business idea, a course, a book, a website, a client proposal, a job search, a study plan.

Exclude completely:
- Definitions, word meanings, trivia, quick facts
- One-off tasks finished inside the chat (a rewritten email, a translation, a recipe, a quick code fix)
- Casual, emotional, or entertainment conversations
- Random curiosity questions

If unsure, exclude it and count it as "borderline". Keep track of how many chats you scanned, how many you excluded, and how many were borderline.

STEP 2: COLLECT THE FACTS FOR EACH PROJECT
If I started the same idea in multiple chats, group those chats as ONE project. For every project record exactly these facts:
- name: as described in the repeatability rules.
- started: the date of my first message about it, as YYYY-MM-DD.
- last: the date of my most recent message about it in any of its chats, as YYYY-MM-DD.
- exchanges: the total number of my messages about it across all its chats (one message from me plus the reply counts as one exchange).
- activeDays: the number of different calendar days on which I sent a message about it (at least 1).
- outcome: the HIGHEST level that has explicit evidence in the chats.
  0 = nothing beyond the chat itself.
  1 = I shared real material (code, drafts, data, or results).
  2 = I reported using or testing it in the real world, or mentioned a real person, client, or deadline tied to it.
  3 = I said it was deployed, launched, published, sent, delivered, or completed.
  Level 3 needs an explicit statement from me. When in doubt, choose the lower level.
- chats: the number of separate chats where I started this idea (1 if never restarted).
- stakes: true if the chats mention a real client, customer, deadline, revenue, or a business or career purpose. Otherwise false.
- type (optional): one of "app", "content", "business", "learning", "client", or "other", only when the kind of project is clear from the chats. Leave it unset if it is not obvious. This sharpens the patterns in Step 4 but never changes a score.

STEP 3: HOW THE TEMPLATE SCORES (for your information: do not calculate anything yourself)
- Category, checked in this order using today's date: SHIPPED if outcome is 3. ALIVE if the last activity was 30 or fewer days ago and either exchanges are 4 or more, activeDays is 2 or more, or the last activity was fewer than 14 days ago. BURIED if exchanges are 3 or fewer and activeDays is 1. STALLED in every other case. CLOSED comes only from my own answers in the update loop.
- Project Score: each category has a band (SHIPPED 90 to 100, ALIVE 60 to 80, STALLED 20 to 40, BURIED 0 to 10). The score is the band start plus the band width times a strength value made of 40 percent depth (exchanges, up to 20), 20 percent returns (activeDays, up to 4), 20 percent recency (full at 0 days idle, zero at 90 days), and 20 percent outcome level.
- Total AGR Score: the average of all Project Scores (closed projects excluded), minus 2 points for each project started in 2 or more chats, capped at 10 points total, rounded to a whole number, minimum 0.
- Tiers: 80-100 Shipper, 60-79 Steady Builder, 40-59 Sparks and Embers, 20-39 Graveyard Keeper, 0-19 Cemetery Owner.
- The verdict, habit, patterns, revive list, and pay-to-play table are also written by the template from the numbers.

STEP 4: BUILD THE REPORT (JSX DASHBOARD)
A. Finish collecting all facts first. Then output ONE React component as the report. Copy the template between the TEMPLATE START and TEMPLATE END markers below EXACTLY, and replace ONLY the values inside the DATA object.

B. How to fill DATA:
- generatedOn: today's date as YYYY-MM-DD.
- periodStart and periodEnd: the dates you covered, as YYYY-MM-DD.
- provisional: true if you could only see part of my history, otherwise false.
- scan: scanned (chats you looked at), excluded (chats you filtered out), borderline (chats you were unsure about).
- redacted: false unless I ask you to hide real project names (for example, before I share the report with someone else). Setting it to true makes the dashboard show "Project 1", "Project 2", and so on instead of real names, everywhere a name would otherwise appear. It never changes any score.
- shareCard: false unless I ask for a version I can post or share publicly. Setting it to true hides the project table, the revive list, and the pay-to-play list, leaving only the score, tier, verdict, metrics, score history, and patterns, none of which name a project. Turning this on also behaves as if redacted were true.
- history: [] on a first report with nothing pasted. Otherwise one entry per previous report I pasted, as described in Step 0.
- projects: one object for EVERY project with exactly these fields: name, started, last, exchanges, activeDays, outcome, chats, stakes, and type if you set one. Do not add userStatus on the first report. The order does not matter.

C. Rules for the component:
- Every value in the template's DATA is SAMPLE DATA. Replace all of it. No sample project may remain.
- Do not change the code, styles, layout, or wording outside DATA. Fix a syntax error only if you must.
- It must stay a single file with a default export, importing only React. No other libraries, fonts, images, or browser storage.

D. How to show it: the report is ALWAYS delivered as this JSX component, for every user, in every environment. Render it live if you can (for example as an artifact, in a canvas, or in any preview that runs React). If your environment cannot render React, output the finished component in full inside one jsx code block so I can paste it into any React sandbox to see my scores. Never replace it with markdown tables or a plain-text report.

E. After the component, write exactly one line in chat: "Your AGR Score and tier are at the top of the dashboard. Based on N projects." Do not write any score in chat, because the template computes it. Then go straight to Step 5.

=== TEMPLATE START ===
import React from "react";

/* AI GRAVEYARD REPORT (AGR Score™) - report template, method v3.0
   Created by Tieyiwe Bassole, Founder of TIBLOGICS, 2026.
   Edit ONLY the DATA object. Every value in it below is SAMPLE DATA to be replaced.
   This component computes every category, score, tier, metric, and sentence from the facts in DATA. */

const DATA = {
  generatedOn: "2026-09-23",
  periodStart: "2024-09-23",
  periodEnd: "2026-09-23",
  provisional: false,
  redacted: false, // true hides real project names everywhere (shows "Project 1", "Project 2", ...)
  shareCard: false, // true shows only the public-safe summary: no project table, revive list, or pay-to-play list
  scan: { scanned: 412, excluded: 371, borderline: 3 },
  // history: one entry per earlier report I pasted, so the dashboard can show a score trend.
  // { date: that report's generatedOn, score: that report's total AGR Score, computed with the Step 3 formula }
  history: [
    { date: "2026-07-26", score: 34 },
    { date: "2026-08-25", score: 41 },
  ],
  // Add userStatus ("shipped", "alive", "stalled", "buried", or "closed") to a project ONLY after I confirm it in the update loop.
  // type is optional: "app", "content", "business", "learning", "client", or "other". Leave unset if unclear.
  projects: [
    { name: "Booking App", started: "2026-01-12", last: "2026-08-14", exchanges: 42, activeDays: 11, outcome: 3, chats: 1, stakes: true, type: "app" },
    { name: "Course Outline", started: "2026-06-03", last: "2026-09-18", exchanges: 30, activeDays: 9, outcome: 1, chats: 1, stakes: true, type: "content" },
    { name: "Newsletter Plan", started: "2026-04-10", last: "2026-09-11", exchanges: 18, activeDays: 6, outcome: 1, chats: 2, stakes: true, type: "content" },
    { name: "Analytics Dashboard", started: "2026-02-05", last: "2026-04-25", exchanges: 22, activeDays: 5, outcome: 1, chats: 1, stakes: true, type: "app" },
    { name: "Podcast Launch", started: "2026-03-02", last: "2026-05-25", exchanges: 15, activeDays: 4, outcome: 0, chats: 1, stakes: true, type: "content" },
    { name: "Recipe App", started: "2026-01-20", last: "2026-03-26", exchanges: 12, activeDays: 3, outcome: 0, chats: 1, stakes: false, type: "app" },
    { name: "Fitness Tracker", started: "2026-07-08", last: "2026-07-08", exchanges: 3, activeDays: 1, outcome: 0, chats: 3, stakes: false, type: "app" },
    { name: "Travel Blog", started: "2026-05-14", last: "2026-05-14", exchanges: 2, activeDays: 1, outcome: 0, chats: 1, stakes: true, type: "content" },
    { name: "Budget Tool", started: "2026-08-05", last: "2026-08-05", exchanges: 3, activeDays: 1, outcome: 0, chats: 1, stakes: false, type: "app" },
    { name: "Logo Ideas", started: "2026-06-15", last: "2026-06-15", exchanges: 1, activeDays: 1, outcome: 0, chats: 1, stakes: false, type: "business" },
  ],
};

/* ---------- constants and helpers (do not edit) ---------- */
const CATS = [
  { key: "shipped", label: "Shipped", band: [90, 100] },
  { key: "alive", label: "Alive", band: [60, 80] },
  { key: "stalled", label: "Stalled", band: [20, 40] },
  { key: "buried", label: "Buried", band: [0, 10] },
];
const TIERS = [
  { name: "Shipper", min: 80, max: 100, verdict: "You finish what you start. Keep shipping and protect your focus.", habit: "Keep one shipping day every week and protect it." },
  { name: "Steady Builder", min: 60, max: 79, verdict: "You build steadily and ship some of it. Tighten the finish and you become a Shipper.", habit: "Give every active project one next action and a date." },
  { name: "Sparks and Embers", min: 40, max: 59, verdict: "Plenty of sparks, not enough finished work. Pick two projects and take them to the finish line.", habit: "Limit yourself to two active projects until one ships." },
  { name: "Graveyard Keeper", min: 20, max: 39, verdict: "You start far more than you finish. Revive or close the graveyard before starting anything new.", habit: "Do not start a new project until you revive or close one." },
  { name: "Cemetery Owner", min: 0, max: 19, verdict: "Most of your projects never got past the first plan. One finished project will move this score fast.", habit: "Pick one project and finish a small version of it this week." },
];
const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
const STATUSES = ["shipped", "alive", "stalled", "buried", "closed"];
const TYPES = { app: "software/app", content: "content", business: "business/venture", learning: "learning", client: "client work", other: "other" };
const DAY = 86400000;
const ms = (iso) => Date.UTC(+iso.slice(0, 4), +iso.slice(5, 7) - 1, +iso.slice(8, 10));
const days = (a, b) => Math.max(0, Math.round((ms(b) - ms(a)) / DAY));
const fmt = (iso) => MONTHS[+iso.slice(5, 7) - 1] + " " + iso.slice(0, 4);
const int = (v, lo, hi) => Math.min(hi, Math.max(lo, Math.round(Number(v) || 0)));
const tierIndex = (s) => Math.max(0, TIERS.findIndex((t) => s >= t.min && s <= t.max));
const pct = (a, b) => (b ? Math.round((a / b) * 100) : 0);
const r1 = (x) => Math.round(x * 10) / 10;
const label = (k) => (CATS.find((c) => c.key === k) || { label: "Closed" }).label;
const plural = (n, w) => n + " " + w + (n === 1 ? "" : "s");
const order = (a, b) => (b.score ?? -1) - (a.score ?? -1) || b.ex - a.ex || a.name.localeCompare(b.name);

/* Fixed method: the same facts and the same date always give the same result. */
function evaluate(list, asOf, useUpdates) {
  const rows = list.map((p, idx) => {
    const ex = int(p.exchanges, 0, 100000);
    const ad = int(p.activeDays, 1, 100000);
    const oc = int(p.outcome, 0, 3);
    const ch = int(p.chats, 1, 1000);
    const idleRaw = days(p.last, asOf);
    const o = useUpdates && STATUSES.includes(p.userStatus) ? p.userStatus : null;
    let category = o;
    if (!category) {
      if (oc >= 3) category = "shipped";
      else if (idleRaw <= 30 && (ex >= 4 || ad >= 2 || idleRaw < 14)) category = "alive";
      else if (ex <= 3 && ad < 2) category = "buried";
      else category = "stalled";
    }
    const cat = CATS.find((c) => c.key === category);
    const idle = o === "alive" ? 0 : idleRaw;
    let score = null;
    if (cat) {
      const ev = (o === "shipped" ? 3 : oc) / 3;
      const s = 0.4 * Math.min(1, ex / 20) + 0.2 * Math.min(1, (ad - 1) / 3) + 0.2 * Math.max(0, 1 - idle / 90) + 0.2 * ev;
      score = cat.band[0] + Math.round((cat.band[1] - cat.band[0]) * s);
    }
    return { idx, name: String(p.name), type: TYPES[p.type] ? p.type : null, started: p.started, last: p.last, stakes: !!p.stakes, ex, ad, oc, ch, idleRaw, idle, category, score, confirmed: !!o };
  });
  const scored = rows.filter((r) => r.category !== "closed");
  const n = scored.length;
  const sum = scored.reduce((s, r) => s + r.score, 0);
  const mean = n ? sum / n : 0;
  const restarted = scored.filter((r) => r.ch >= 2).length;
  const penalty = Math.min(10, restarted * 2);
  const total = n ? Math.max(0, Math.round(mean - penalty)) : 0;
  const counts = {};
  CATS.forEach((c) => (counts[c.key] = scored.filter((r) => r.category === c.key).length));
  return { rows, scored, n, sum, mean, restarted, penalty, total, counts, closed: rows.length - n };
}

const CSS = `
.agr{--bg:#f4f6fb;--card:#ffffff;--text:#0f172a;--muted:#5b6478;--line:#e3e7ef;--soft:#eef1f7;--accent:#4f46e5;
--shipped:#15803d;--alive:#1d4ed8;--stalled:#b45309;--buried:#b91c1c;--closed:#6b7280;
--t0:#15803d;--t1:#1d4ed8;--t2:#b45309;--t3:#c2410c;--t4:#b91c1c;
background:var(--bg);color:var(--text);font-family:ui-sans-serif,system-ui,-apple-system,"Segoe UI",Roboto,Helvetica,Arial,sans-serif;padding:24px 16px;line-height:1.5}
@media (prefers-color-scheme:dark){.agr{--bg:#0b1020;--card:#121a2f;--text:#e8ecf5;--muted:#9aa6bf;--line:#243050;--soft:#1a2440;--accent:#818cf8;
--shipped:#4ade80;--alive:#60a5fa;--stalled:#fbbf24;--buried:#f87171;--closed:#9ca3af;
--t0:#4ade80;--t1:#60a5fa;--t2:#fbbf24;--t3:#fb923c;--t4:#f87171}}
.agr *{box-sizing:border-box}
.agr .wrap{max-width:980px;margin:0 auto;display:grid;gap:16px}
.agr .card{background:var(--card);border:1px solid var(--line);border-radius:16px;padding:20px;min-width:0}
.agr h1{font-size:26px;line-height:1.15;margin:0;letter-spacing:-.01em}
.agr h2{font-size:13px;letter-spacing:.08em;text-transform:uppercase;color:var(--muted);margin:0 0 14px;font-weight:700}
.agr .sub{color:var(--muted);font-size:14px;margin-top:6px}
.agr .top{display:flex;flex-wrap:wrap;gap:12px;justify-content:space-between;align-items:flex-end}
.agr .badges{display:flex;flex-wrap:wrap;gap:8px}
.agr .badge{display:inline-block;padding:3px 10px;border-radius:999px;font-size:12px;font-weight:700;background:var(--soft);color:var(--muted)}
.agr .badge.warn{background:color-mix(in srgb,var(--stalled) 16%,transparent);color:var(--stalled)}
.agr .badge.accent{background:color-mix(in srgb,var(--accent) 16%,transparent);color:var(--accent)}
.agr .spark{width:100%;height:120px;display:block}
.agr .spark-labels{display:flex;justify-content:space-between;font-size:11px;color:var(--muted);margin-top:4px}
.agr .hero{display:grid;grid-template-columns:minmax(220px,300px) 1fr;gap:24px;align-items:center}
.agr .gauge{width:100%;height:auto;display:block}
.agr .g-track{fill:none;stroke:var(--soft);stroke-width:16;stroke-linecap:round}
.agr .g-fill{fill:none;stroke-width:16;stroke-linecap:round}
.agr .g-num{font-size:44px;font-weight:800;fill:var(--text)}
.agr .g-of{font-size:11px;fill:var(--muted)}
.agr .t0{stroke:var(--t0);color:var(--t0)}.agr .t1{stroke:var(--t1);color:var(--t1)}.agr .t2{stroke:var(--t2);color:var(--t2)}.agr .t3{stroke:var(--t3);color:var(--t3)}.agr .t4{stroke:var(--t4);color:var(--t4)}
.agr .tier{font-size:24px;font-weight:800;margin:0}
.agr .delta{display:inline-block;margin-left:10px;font-size:14px;font-weight:700;padding:2px 10px;border-radius:999px;background:var(--soft)}
.agr .verdict{font-size:17px;margin:8px 0 14px}
.agr .calc{font-size:13px;color:var(--muted);background:var(--soft);border-radius:10px;padding:10px 12px}
.agr .stats{display:flex;flex-wrap:wrap;gap:8px;margin-top:12px}
.agr .stat{font-size:13px;background:var(--soft);border-radius:10px;padding:6px 10px}
.agr .stat b{font-size:15px}
.agr .cols{display:grid;grid-template-columns:1fr 1fr;gap:16px}
.agr .ladder{display:grid;gap:8px}
.agr .rung{display:flex;justify-content:space-between;align-items:center;gap:10px;padding:10px 12px;border-radius:10px;border:1px solid var(--line);font-size:14px}
.agr .rung.on{border-color:var(--accent);background:color-mix(in srgb,var(--accent) 10%,transparent);font-weight:700}
.agr .here{font-size:11px;font-weight:800;letter-spacing:.06em;color:var(--accent)}
.agr table{width:100%;border-collapse:collapse;font-size:14px}
.agr th{font-size:11px;letter-spacing:.06em;text-transform:uppercase;color:var(--muted);text-align:left;padding:8px 10px;border-bottom:1px solid var(--line);white-space:nowrap}
.agr td{padding:10px;border-bottom:1px solid var(--line);vertical-align:middle}
.agr tr:last-child td{border-bottom:none}
.agr .num{text-align:right;font-variant-numeric:tabular-nums}
.agr .scroll{overflow-x:auto}
.agr .nw{white-space:nowrap}
.agr .pill{display:inline-flex;align-items:center;gap:6px;padding:2px 10px;border-radius:999px;font-size:12px;font-weight:700;white-space:nowrap;color:var(--c);background:color-mix(in srgb,var(--c) 14%,transparent)}
.agr .dot{width:8px;height:8px;border-radius:50%;background:var(--c);flex:none}
.agr .c-shipped{--c:var(--shipped)}.agr .c-alive{--c:var(--alive)}.agr .c-stalled{--c:var(--stalled)}.agr .c-buried{--c:var(--buried)}.agr .c-closed{--c:var(--closed)}
.agr .bar{height:8px;min-width:60px;border-radius:999px;background:var(--soft);overflow:hidden}
.agr .bar i{display:block;height:100%;background:var(--c);border-radius:999px}
.agr .sc{display:flex;align-items:center;gap:8px;min-width:110px}.agr .sc b{width:28px;text-align:right;font-variant-numeric:tabular-nums}.agr .sc .bar{flex:1}
.agr .metrics{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:12px}
.agr .metric{background:var(--soft);border-radius:12px;padding:14px}
.agr .metric .k{font-size:12px;color:var(--muted);font-weight:700}
.agr .metric .v{font-size:24px;font-weight:800;margin:2px 0}
.agr .metric .n{font-size:12px;color:var(--muted)}
.agr .pat{display:grid;gap:10px}
.agr .pat>div{display:flex;gap:12px;align-items:flex-start;background:var(--soft);border-radius:12px;padding:12px 14px;font-size:15px}
.agr .pat span{flex:none;width:24px;height:24px;border-radius:50%;background:var(--accent);color:#fff;font-size:13px;font-weight:800;display:flex;align-items:center;justify-content:center}
.agr .rev{display:grid;gap:10px}
.agr .rev>div{border:1px solid var(--line);border-radius:12px;padding:12px 14px;font-size:14px}
.agr .rev b{display:block;margin-bottom:2px}
.agr .habit{border-left:4px solid var(--accent);background:color-mix(in srgb,var(--accent) 8%,transparent);border-radius:0 12px 12px 0;padding:14px 16px;font-size:16px;font-weight:600}
.agr .foot{font-size:12px;color:var(--muted);text-align:center;padding:4px 0 8px}
.agr .promo{font-size:12px;color:var(--muted);text-align:center;padding:0 0 10px}
.agr .promo a{color:var(--accent);font-weight:700;text-decoration:none}
.agr .promo-card{background:color-mix(in srgb,var(--accent) 10%,transparent);border:1px solid var(--accent);border-radius:12px;padding:14px 16px;text-align:center;font-size:15px;font-weight:700}
.agr .promo-card a{color:var(--accent);text-decoration:none;font-weight:800}
.agr .empty{text-align:center;padding:40px 16px}
@media (max-width:720px){.agr .hide-m{display:none}.agr .hero,.agr .cols{grid-template-columns:1fr}.agr h1{font-size:22px}.agr{padding:16px 12px}}
`;

function Gauge({ value, idx }) {
  const len = Math.PI * 80;
  return (
    <svg className="gauge" viewBox="0 0 200 118" role="img" aria-label={"AGR Score " + value + " out of 100"}>
      <path className="g-track" d="M20 100 A80 80 0 0 1 180 100" />
      <path className={"g-fill t" + idx} d="M20 100 A80 80 0 0 1 180 100" style={{ strokeDasharray: (value / 100) * len + " " + len }} />
      <text className="g-num" x="100" y="90" textAnchor="middle">{value}</text>
      <text className="g-of" x="100" y="110" textAnchor="middle">out of 100</text>
    </svg>
  );
}

function Pill({ k }) {
  return (
    <span className={"pill c-" + k}>
      <span className="dot" />
      {label(k)}
    </span>
  );
}

function Sparkline({ points }) {
  const w = 400, h = 120, pad = 18;
  const n = points.length;
  const x = (i) => (n > 1 ? pad + (i * (w - 2 * pad)) / (n - 1) : w / 2);
  const y = (v) => pad + (1 - v / 100) * (h - 2 * pad);
  const path = points.map((p, i) => (i === 0 ? "M" : "L") + x(i).toFixed(1) + "," + y(p.score).toFixed(1)).join(" ");
  return (
    <svg className="spark" viewBox={"0 0 " + w + " " + h} role="img" aria-label="AGR Score history">
      <path d={path} fill="none" stroke="var(--accent)" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" />
      {points.map((p, i) => (
        <circle key={i} cx={x(i)} cy={y(p.score)} r={i === n - 1 ? 7 : 5} fill={i === n - 1 ? "var(--accent)" : "var(--muted)"} />
      ))}
    </svg>
  );
}

export default function AGRReport() {
  const d = DATA;
  const list = d.projects || [];
  const hasUpdates = list.some((p) => STATUSES.includes(p.userStatus));
  const A = evaluate(list, d.generatedOn, true);
  const B = hasUpdates ? evaluate(list, d.generatedOn, false) : null;
  const { rows, scored, n, sum, mean, restarted, penalty, total, counts, closed } = A;
  const idx = tierIndex(total);
  const delta = B ? total - B.total : null;
  const active = counts.shipped + counts.alive + counts.stalled;
  const dorm = scored.filter((r) => r.category === "stalled" || r.category === "buried");
  const months = Math.max(1, Math.round(days(d.periodStart, d.periodEnd) / 30.44));
  const shippedRows = scored.filter((r) => r.category === "shipped");
  const deep = scored.filter((r) => r.ex > 3).length;
  const avg = (arr, f) => (arr.length ? Math.round(arr.reduce((s, r) => s + f(r), 0) / arr.length) : 0);
  const avgOf = (k) => {
    const a = scored.filter((r) => r.category === k);
    return a.length ? Math.round(a.reduce((s, r) => s + r.score, 0) / a.length) : "-";
  };
  const metrics = [
    { k: "Depth Rate", v: pct(deep, n) + "%", n: "Projects that went beyond 3 exchanges" },
    { k: "Follow-Through Rate", v: pct(counts.shipped, active) + "%", n: "Shipped out of everything you got moving" },
    { k: "Restart Rate", v: pct(restarted, n) + "%", n: "Ideas started again in new chats" },
    { k: "Average Dormancy", v: dorm.length ? avg(dorm, (r) => r.idle) + " days" : "-", n: "Time Stalled and Buried projects have sat idle" },
    { k: "Start vs Finish Pace", v: r1(rows.length / months) + " / " + r1(counts.shipped / months), n: "New projects vs shipped, per month" },
  ];
  const patterns = [
    deep + " of " + n + " projects (" + pct(deep, n) + "%) went beyond 3 exchanges.",
    shippedRows.length
      ? "Your " + plural(shippedRows.length, "shipped project") + " averaged " + avg(shippedRows, (r) => r.ex) + " exchanges over " + avg(shippedRows, (r) => r.ad) + " active days."
      : "None of your projects has shipped yet.",
    dorm.length
      ? "Your " + plural(dorm.length, "stalled or buried project") + " have been idle " + avg(dorm, (r) => r.idle) + " days on average."
      : "You have no stalled or buried projects.",
  ];
  const byType = {};
  scored.forEach((r) => { if (r.type) (byType[r.type] = byType[r.type] || []).push(r); });
  const typeStats = Object.keys(byType)
    .map((k) => ({ k, arr: byType[k], shipped: pct(byType[k].filter((r) => r.category === "shipped").length, byType[k].length) }))
    .filter((t) => t.arr.length >= 2)
    .sort((a, b) => a.shipped - b.shipped);
  if (typeStats.length >= 2) {
    const worst = typeStats[0];
    patterns.push("Your " + TYPES[worst.k] + " projects finish least often: " + worst.shipped + "% shipped across " + plural(worst.arr.length, "project") + ".");
  }
  const hist = (Array.isArray(d.history) ? d.history : []).filter((h) => h && h.date && typeof h.score === "number");
  const points = [...hist, { date: d.generatedOn, score: total }].sort((a, b) => (a.date < b.date ? -1 : a.date > b.date ? 1 : 0));
  const displayName = (r) => (d.redacted ? "Project " + (r.idx + 1) : r.name);
  const revive = scored.filter((r) => r.category === "stalled").sort(order).slice(0, 3);
  const buried = scored.filter((r) => r.category === "buried").sort(order);
  const shown = [...rows].sort(order).sort((a, b) => b.ex - a.ex).slice(0, 25).sort(order);
  const rest = rows.length - shown.length;
  const changes = B
    ? rows.map((r, i) => ({ r, b: B.rows[i] })).filter((x) => x.r.confirmed && x.r.category !== x.b.category)
    : [];
  const evidence = (r) =>
    plural(r.ex, "exchange") + " over " + plural(r.ad, "day") + ", last active " + plural(r.idleRaw, "day") + " ago" +
    (r.oc === 3 ? ", shipped" : r.oc === 2 ? ", real-world use" : r.oc === 1 ? ", real material shared" : "") +
    (r.confirmed ? ". Confirmed by you." : "");

  if (!n) {
    return (
      <div className="agr">
        <style>{CSS}</style>
        <div className="wrap"><div className="card empty"><h1>No qualifying projects found</h1><p className="sub">Paste or upload your chat history and run the report again.</p></div></div>
      </div>
    );
  }

  return (
    <div className="agr">
      <style>{CSS}</style>
      <div className="wrap">
        <div className="top">
          <div>
            <h1>AI Graveyard Report</h1>
            <div className="sub">AGR Score™ method v3.0 · {fmt(d.periodStart)} to {fmt(d.periodEnd)} · as of {d.generatedOn}</div>
          </div>
          <div className="badges">
            {d.provisional && <span className="badge warn">PROVISIONAL: based on {n} projects</span>}
            {d.shareCard && <span className="badge accent">SHARE CARD · project list hidden</span>}
            {d.redacted && !d.shareCard && <span className="badge accent">NAMES REDACTED</span>}
          </div>
        </div>

        <div className="card hero">
          <Gauge value={total} idx={idx} />
          <div>
            <h2>Total AGR Score</h2>
            <p className={"tier t" + idx}>
              {TIERS[idx].name}
              {delta !== null && <span className="delta">{B.total} to {total} ({delta >= 0 ? "+" : ""}{delta} {delta >= 0 ? "▲" : "▼"})</span>}
            </p>
            <p className="verdict">{TIERS[idx].verdict}</p>
            <div className="calc">Sum of project scores {sum} / {n} projects = {r1(mean)}. Minus restart penalty {penalty} = <b>{total}</b></div>
            <div className="stats">
              <span className="stat"><b>{d.scan.scanned}</b> chats scanned</span>
              <span className="stat"><b>{d.scan.excluded}</b> excluded</span>
              <span className="stat"><b>{n}</b> projects{closed ? " (+" + closed + " closed)" : ""}</span>
              {d.scan.borderline ? <span className="stat"><b>{d.scan.borderline}</b> borderline</span> : null}
            </div>
          </div>
        </div>

        <div className="cols">
          <div className="card">
            <h2>Tier ladder</h2>
            <div className="ladder">
              {TIERS.map((t, i) => (
                <div key={t.name} className={"rung" + (i === idx ? " on" : "")}>
                  <span>{t.name}</span>
                  <span>{t.min} to {t.max}{i === idx && <span className="here">  ◄ YOU ARE HERE</span>}</span>
                </div>
              ))}
            </div>
          </div>
          <div className="card">
            <h2>Category breakdown</h2>
            <div className="scroll">
              <table>
                <thead><tr><th>Category</th><th className="num">Projects</th><th className="num">Share</th><th className="num">Avg</th><th className="hide-m">Bar</th></tr></thead>
                <tbody>
                  {CATS.map((c) => (
                    <tr key={c.key} className={"c-" + c.key}>
                      <td><Pill k={c.key} /></td>
                      <td className="num">{B ? B.counts[c.key] + " to " : ""}{counts[c.key]}</td>
                      <td className="num">{pct(counts[c.key], n)}%</td>
                      <td className="num">{avgOf(c.key)}</td>
                      <td className="hide-m" style={{ minWidth: 90 }}><div className="bar"><i style={{ width: pct(counts[c.key], n) + "%" }} /></div></td>
                    </tr>
                  ))}
                  <tr><td><b>Total</b></td><td className="num"><b>{n}</b></td><td className="num">100%</td><td className="num"><b>{Math.round(mean)}</b></td><td className="hide-m" /></tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>

        <div className="card">
          <h2>Key metrics</h2>
          <div className="metrics">
            {metrics.map((m) => (
              <div className="metric" key={m.k}><div className="k">{m.k}</div><div className="v">{m.v}</div><div className="n">{m.n}</div></div>
            ))}
          </div>
        </div>

        {points.length > 1 && (
          <div className="card">
            <h2>Score history</h2>
            <Sparkline points={points} />
            <div className="spark-labels"><span>{points[0].date}</span><span>{points[points.length - 1].date}</span></div>
            <p className="sub">{plural(points.length, "report")} on file. Latest: {total} ({TIERS[idx].name}).</p>
          </div>
        )}

        {!d.shareCard && (
        <div className="card">
          <h2>Project scores</h2>
          <div className="scroll">
            <table>
              <thead><tr><th>#</th><th>Project</th><th>Started</th><th className="num">Exch.</th><th>Last activity</th><th>Category</th><th>Score</th><th>Evidence</th></tr></thead>
              <tbody>
                {shown.map((r, i) => (
                  <tr key={r.name + i} className={"c-" + r.category}>
                    <td>{i + 1}</td>
                    <td><b>{displayName(r)}</b>{r.ch >= 2 && <span className="badge" style={{ marginLeft: 6 }}>restarted x{r.ch}</span>}</td>
                    <td className="nw">{fmt(r.started)}</td>
                    <td className="num">{r.ex}</td>
                    <td className="nw">{fmt(r.last)}</td>
                    <td><Pill k={r.category} /></td>
                    <td>{r.score === null ? "-" : <div className="sc"><b>{r.score}</b><div className="bar"><i style={{ width: r.score + "%" }} /></div></div>}</td>
                    <td style={{ minWidth: 220 }}>{evidence(r)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {rest > 0 && <p className="sub">Plus {rest} more projects included in the total.</p>}
        </div>
        )}

        {!d.shareCard && changes.length > 0 && (
          <div className="card">
            <h2>What changed after your updates</h2>
            <div className="scroll">
              <table>
                <thead><tr><th>Project</th><th>Before</th><th>After</th></tr></thead>
                <tbody>
                  {changes.map((x, i) => (
                    <tr key={i}>
                      <td><b>{displayName(x.r)}</b></td>
                      <td><Pill k={x.b.category} /> {x.b.score ?? "-"}</td>
                      <td><Pill k={x.r.category} /> {x.r.score ?? "-"}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {!d.shareCard ? (
        <div className="cols">
          <div className="card">
            <h2>Patterns</h2>
            <div className="pat">
              {patterns.map((t, i) => (<div key={i}><span>{i + 1}</span><p style={{ margin: 0 }}>{t}</p></div>))}
            </div>
          </div>
          <div className="card">
            <h2>Revive these first</h2>
            <div className="rev">
              {revive.length ? revive.map((r, i) => (
                <div key={i}><b>{displayName(r)} ({r.score})</b>30-minute action: {r.oc >= 1 ? "Reopen the last draft or code you shared and finish the next small piece." : "Write a one-page spec: who it is for, the core job, and what is out of scope."}</div>
              )) : <div>No stalled projects to revive.</div>}
            </div>
          </div>
        </div>
        ) : (
        <div className="card">
          <h2>Patterns</h2>
          <div className="pat">
            {patterns.map((t, i) => (<div key={i}><span>{i + 1}</span><p style={{ margin: 0 }}>{t}</p></div>))}
          </div>
        </div>
        )}

        {!d.shareCard && (
        <div className="card">
          <h2>Pay-to-play test (would you have paid a professional?)</h2>
          <div className="scroll">
            <table>
              <thead><tr><th>Buried project</th><th>Would I have paid?</th><th>Recommendation</th></tr></thead>
              <tbody>
                {buried.length ? buried.map((r, i) => (
                  <tr key={i}><td><b>{displayName(r)}</b></td><td>{r.stakes ? "Yes" : "No"}</td><td>{r.stakes ? "Revive" : "Close on purpose"}</td></tr>
                )) : <tr><td colSpan="3">No buried projects.</td></tr>}
              </tbody>
            </table>
          </div>
        </div>
        )}

        <div className="habit">One habit until your next report: {TIERS[idx].habit}</div>

        {d.shareCard && (
        <div className="promo-card">
          Go from amateur to AI-ready: get trained by ARFA (AI Readiness For All), from TIBLOGICS. <a href="https://tiblogics.com/learning-box" target="_blank" rel="noopener noreferrer">tiblogics.com/learning-box</a>
        </div>
        )}

        <div className="foot">The AI Graveyard Report Score (AGR Score™) was created by Tieyiwe Bassole, Founder of TIBLOGICS, 2026. Every score is computed by a fixed formula from chat facts, so the same chats on the same date give the same score. Re-run in 30 days.</div>
        <div className="promo">Go from amateur to AI-ready: get trained by ARFA (AI Readiness For All) at <a href="https://tiblogics.com/learning-box" target="_blank" rel="noopener noreferrer">tiblogics.com/learning-box</a>.</div>
      </div>
    </div>
  );
}
=== TEMPLATE END ===

STEP 5: UPDATE LOOP (interactive)
Immediately after the report, ask me: "Want to give me updates on some of these projects? I'll ask about them one at a time, and you can stop whenever you like."

If I say yes:
- Keep your DATA object as the source of truth and update it as we go.
- Go through the projects one at a time, starting with the projects the template classified as STALLED or BURIED, the ones with the most exchanges first, then A to Z by name. If I name specific projects, start with those.
- Ask ONE short question per project, then wait for my answer. Use natural wording such as:
  - For Buried or Stalled: "Did you ever act on [project]?" or "What's the update with [project]?"
  - For Alive: "How far along is [project] now?"
- Map my answer to one status:
  - shipped: I completed, launched, sent, published, or delivered it.
  - alive: I am actively working on it now.
  - stalled: I started it but paused it, and I intend to return.
  - buried: I never acted on it and have no plan to.
  - closed: I decided on purpose not to pursue it. Closed projects are removed from the total (they no longer count for or against the score), because a deliberate decision is not a failure.
- Record it by adding userStatus with that value to the project in DATA. My answer always overrides the category from the chats. Progress I report from outside the chats (offline work, work done in other tools) counts.
- After each answer, confirm in one short line, for example "[Project] is now [status]." Do not state scores, and do not lecture or give advice during this loop. Do not render the component during the loop.
- If I say "skip," move on without changing that project.
- Stop when I say stop or when all projects have been covered.

STEP 6: REVISED REPORT
After the update loop, output the component again, built from the same template. Keep every fact exactly the same and only add the userStatus values I confirmed. The template calculates the before and after scores and shows what changed by itself. Then write exactly one line in chat: "Your revised AGR Score and tier are at the top of the dashboard. It is your baseline for the next report." Tell me to keep the code of this report and paste it into my next run so it starts from these facts.

STEP 7: RECURRING
End by suggesting I re-run this in 30 days and compare against the revised score. Tell me that scores only move when my chats change or when time passes, because idle time is measured up to today's date. If you have a tool that can schedule a task or a reminder, offer to set one up for 30 days from today, and only create it if I say yes.

STEP 8: SHARE CARD (on request, any time)
If I ask you to make my score shareable or postable, or to hide my project names, re-render the exact same component with the same DATA, but set redacted to true (and shareCard to true if I want the public-safe summary version). Do not change any fact or any score to do this. Tell me in one short line that project names are hidden in this version, and that I can ask for the full version back at any time by asking for it with real names.

STEP 9: SIMULATOR (on request, any time)
If I ask what my score would be if something changed (for example "what if I shipped Course Outline" or "what if I close Logo Ideas"), do not edit DATA or render the component. Instead, apply the Step 3 formula by hand to that one hypothetical change and tell me the before and after total in one or two lines, making clear this is a simulation. Only make the change real, by updating DATA, if I confirm it through the update loop in Step 5.

TONE: honest, direct, and encouraging. No shaming, no filler. Do not use em dashes.